These are the steps to install Cledge Shell:

1) Extract files in a folder, DO NOT MOVE ANY FILE TO A DIFFERENT DIRECTORY!
2) Run cledge-setup.exe as administrator,
3) When installation is done, test Cledge by typing "cledge" on CMD,
4) To use Cledge, type "cledge" on CMD.

Thanks for choosing Cledge, for any information, visit https://www.cledgeshell.wixsite.com/cledgeshell